import java.awt.*;
import java.applet.*;
public class ManzoorPeriod2 extends Applet {
public void init() {}
public void paint(Graphics g) {
scaleSponge(g, 100, 100, 250, 300);//paints one image
scaleSponge(g, 10, 60, 110, 160);
scaleSponge(g, 300, 10, 260, 410);
scaleSponge(g, 400, 500, 350, 400);
scaleSponge(g, 800, 250, 400, 500);
//paint at least 4 more here
}

public void scaleSponge(Graphics g, int xPos, int yPos, int widthPos, int lengthPos) {
int x = xPos;
int y = yPos;
int width = widthPos;
int length = lengthPos;
g.setColor(Color.black);
g.fillRect(x, y, width, length);
/*Mr. Fenson Period 1337 09/21/2015
* This program makes a picture to make fun of the student who compiles it
* Said student should go through the entire code and fix all errers.
* Student should also comment every line of code using //
* Pre-Conditions: Student doesn't know anything, student can't type his own code
* Post-Conditions: Student learned Mr. Fenson's bad humor, student over came the challenge,
* student knows how to code, student most importantly knows to ask questions!
*/




//TYPE YOUR CODE BELOW HERE
Color myColor = new Color(244,204,142);//Red,Green,Blue
g.setColor(myColor);;//tan
    g.fillOval(x+width*4/12, y, width*4/12, length*4/15); //draws head
    g.fillOval(x+width*0/12, y+length*4/15,width*1/12, length*1/15); //makes left hand
    g.fillOval(x+width*11/12, y+length*4/15, width*1/12, length*1/15); //makes right hand
    
Color mycolor = new Color(157,112,241);//Red,Green,Blue
g.setColor(mycolor);//makes shirt purplish color
    g.fillRect(x+width*5/12, y+length*4/15, width*2/12, length*6/15); //Draws body; chest & torso 
    g.fillRect(x+width*1/12, y+length*4/15, width*4/12, length*1/15); //makes left arm
    g.fillRect(x+width*7/12, y+length*4/15, width*4/12, length*1/15); //makes right arm

Color myColour = new Color(117,170,236);//Red,Green,Blue
g.setColor(myColour); //Makes pants blue
    g.fillRect(x+width*5/12, y+length*10/15, width*1/12, length*4/15); //draws left leg
    g.fillRect(x+width*6/12, y+length*10/15, width*1/12, length*4/15); //makes right leg
    
Color mycolour = new Color(142,181,144);//Red,Green,Blue
g.setColor(mycolour); // darker blue
    g.drawLine(x+width*6/12, y+length*10/15, x + width*6/12, y + length*14/15);//seperates pant legs    

g.setColor( Color. gray );//makes shoe gray
    g.fillOval(x+width*5/12, y+length*14/15, width*1/12, length*1/15); //makes left shoe
    g.fillOval(x+width*6/12, y+length*14/15, width*1/12, length*1/15); //makes right shoe

//STOP TYPING CODE
g.drawString("Afeefah Manzoor, Period 2",0,20);//my name and class
}
}
