public class Board 
{
   private static Player[][] board=new Player[8][8];
   //private static ArrayList<String> list = new ArrayList<String>();
   public static void main(String[] args) {      
      for(int i=0;i<3;i++){
         for(int j=0;j<board[0].length;j++){
            if(i%2==1){
               if(j%2==1){
                  board[i][j]=new Man(i,j,true);
              }
            }
            if(i%2==0){
               if(j%2==0){ 
                  board[i][j]=new Man(i,j,true);
               }
            }
         }
      }
      for(int i=5;i<8;i++){
         for(int j=0;j<board[0].length;j++){
            if(i%2==0){
               if(j%2==0){
                  board[i][j]=new Man(i,j,false);
              }
            }
            if(i%2==1){
               if(j%2==1){ 
                  board[i][j]=new Man(i,j,false);
               }
            }
         }
      }
      for(int i=0;i<board.length;i++){
         for(int j=0;j<board[0].length;j++){
            if(board[i][j]==null)
               System.out.print("0 ");
            else if(board[i][j].getTeam())
               System.out.print("1 ");
            else
               System.out.print("2 ");
         }
         System.out.println();
      }
   }
}