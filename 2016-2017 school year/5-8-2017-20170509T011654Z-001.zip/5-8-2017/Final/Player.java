public abstract class Player implements Movement{
   public abstract void move(int dir);
   public abstract boolean jump();
   public abstract boolean getTeam(); 
   /*
   public boolean blackLose(){
      if(blackCount<=0)
         return true;
      else 
         return false;
   }
   public boolean redLose(){
      if(redCount<=0)
         return true;
      else
         return false;
   }
   */
}