public class King extends Player{
   private int x;
   private int y;
   private boolean redTeam;
   public King(int xPos,int yPos,boolean teamColor){ //true = red false = black
      x=xPos;
      y=yPos;
      redTeam=teamColor;
   }
   public int getX(){
      return x;
   }
   public int getY(){
      return y;
   }
   public boolean getTeam(){
      return redTeam;
   }
   public void move(int dir){
      if(dir==7){
         x--;
         y--;
      }
      else if(dir==9){
         x--;
         y++;
      }
      else if(dir==1){
         x++;
         y--;
      }
      else if(dir==3){
         x++;
         y++;
      }
   }
   public boolean jump(){
      return false;
   }
   public void setX(int newX){
      x=newX;
   }
   public void setY(int newY){
      y=newY;
   }
}