public interface Movement{
   public void move(int dir);
   public boolean jump();
}