public class Man extends King{
   public Man(int xPos,int yPos, boolean teamColor){
      super(xPos,yPos,teamColor);
   }
   public void move(int dir){
      if(dir==4){
         if(this.getY()==0){
            return;
         }
         if(super.getTeam()){
            super.setX(this.getX()-1);
            super.setY(this.getY()-1);
         }
         else{
            super.setX(this.getX()-1);
            super.setY(this.getY()-1);
         }
      }
      else if(dir==6){
         if(this.getY()==7){
            return;
         }
         if(super.getTeam()){
            super.setX(this.getX()+1);
            super.setY(this.getY()+1);
         }
         else{
            super.setX(this.getX()+1);
            super.setY(this.getY()+1);
         }
      }
   }
}